/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USER
 */
public class Almacen {
    private String idalmacen;
    private String nombrealmacen;
    private String direccionalmacen;
    private String telefonoalmacen;

    public Almacen(String idalmacen, String nombrealmacen, String direccionalmacen, String telefonoalmacen) {
        this.idalmacen = idalmacen;
        this.nombrealmacen = nombrealmacen;
        this.direccionalmacen = direccionalmacen;
        this.telefonoalmacen = telefonoalmacen;
    }

    public Almacen() {
    }
    
    

    public String getIdamacen() {
        return idalmacen;
    }

    public void setIdamacen(String idamacen) {
        this.idalmacen = idamacen;
    }

    public String getNombrealmacen() {
        return nombrealmacen;
    }

    public void setNombrealmacen(String nombrealmacen) {
        this.nombrealmacen = nombrealmacen;
    }

    public String getDireccionalmacen() {
        return direccionalmacen;
    }

    public void setDireccionalmacen(String direccionalmacen) {
        this.direccionalmacen = direccionalmacen;
    }

    public String getTelefonoalmacen() {
        return telefonoalmacen;
    }

    public void setTelefonoalmacen(String telefonoalmacen) {
        this.telefonoalmacen = telefonoalmacen;
    }
}
