/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author Sandrita
 */
public class ModeloProveedor extends Proveedor {

    PgConnection cone = new PgConnection();

    public ModeloProveedor(String idproveedor, String nombreproveedor, String apellidoproveedor, String nombreempresa, String cargo, String direccion, String telefono, int ciudad, int cupoventas) {
        super(idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas);
    }

    public ModeloProveedor() {
    }

    public boolean deleteProveedores(String idproveedor) {
        String sql;
        sql = "delete from proveedor where idProveedor ='" + getIdproveedor() + "';";
        return cone.accion(sql);
    }
//idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;

    public boolean updateProveedores(String idproveedor) {
        String sql;
        sql = "update proveedor set nombreproveedor='" + getNombreproveedor() + "', apellidoproveedor='" + getApellidoproveedor() + "',nombreempresa='" + getNombreempresa() + "',cargo='" + getCargo() + "',direccion='" + getDireccion() + "', telefono='" + getTelefono() + "', cuidad=" + getCiudad() + ", cupoventas=" + getCupoventas() + " where idproveedor='" + idproveedor + "';";
        return cone.accion(sql);
    }

    public boolean setProveedores() {
        String sql;                                                                                                                                        //private String idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
        sql = "insert into proveedor (idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas) values ('" + getIdproveedor() + "', '" + getNombreproveedor() + "', '" + getApellidoproveedor() + "','" + getNombreempresa() + "','" + getCargo() + "','" + getDireccion() + "','" + getTelefono() + "', " + getCiudad() + ", " + getCupoventas() + ");";
        return cone.accion(sql);
    }

//    public boolean setPersonaFoto() {
//        String sql;
//        sql = "insert into personas(idpersona, nombres, apellidos,fechanacimiento, telefono, sexo, sueldo, cupo, foto)";
//        sql += "values (?,?,?,?,?,?,?,?,?)";
//
//        try {
//            PreparedStatement ps = cone.con.prepareStatement(sql);
//            ps.setString(1, getIdpersona());
//            ps.setString(2, getNombres());
//            ps.setString(3, getApellidos());
//            ps.setDate(4, (java.sql.Date) getFechanacimiento());
//            ps.setString(5, getTelefono());
//            ps.setString(6, getSexo());
//            ps.setDouble(7, getSueldo());
//            ps.setInt(8, getCupo());
//            ps.setBinaryStream(9, getImageFile(), getLenght());
//            ps.executeUpdate();
//
//            return true;
//        } catch (SQLException ex) {
//            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            return false;
//        }
//    }
    public List<Proveedor> buscar(String buscar) {
        List<Proveedor> listaProveedores = new ArrayList<>();
        String sql;
        if (buscar.equals(null)) {
            sql = "select idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas from  proveedor"; 
        } else {
            sql = "select idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas from  proveedor"
                    + " WHERE UPPER(nombreproveedor) LIKE UPPER('%" + buscar + "%') OR UPPER(apellidoproveedor) LIKE UPPER('%" + buscar + "%') OR ";
            sql += " UPPER(idproveedor) LIKE UPPER('%" + buscar + "%')";

            try {//idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
                ResultSet rs = cone.consulta(sql);
                while (rs.next()) {
                    Proveedor prov = new Proveedor();
                    prov.setIdproveedor(rs.getString(1));
                    prov.setNombreproveedor(rs.getString(2));
                    prov.setApellidoproveedor(rs.getString(3));
                    prov.setNombreempresa(rs.getString(4));
                    prov.setCargo(rs.getString(5));
                    prov.setDireccion(rs.getString(6));
                    prov.setTelefono(rs.getString(7));
                    prov.setCiudad(rs.getInt(8));
                    prov.setCupoventas(rs.getInt(9));

                    listaProveedores.add(prov);
                }
                rs.close();

            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(ModeloProveedor.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
        return listaProveedores;
    }

    public List<Proveedor> getProveedores() {

        String sql = "select * from proveedor";

        List<Proveedor> listadoproveedores = new ArrayList<>();
        ResultSet rs = cone.consulta(sql);
        try {
            while (rs.next()) {
                Proveedor prov = new Proveedor();
                prov.setIdproveedor(rs.getString(1));
                prov.setNombreproveedor(rs.getString(2));
                prov.setApellidoproveedor(rs.getString(3));
                prov.setNombreempresa(rs.getString(4));
                prov.setCargo(rs.getString(5));
                prov.setDireccion(rs.getString(6));
                prov.setTelefono(rs.getString(7));
                prov.setCiudad(rs.getInt(8));
                prov.setCupoventas(rs.getInt(9));

                listadoproveedores.add(prov);

            }

        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(ModeloProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listadoproveedores;

    }
}
