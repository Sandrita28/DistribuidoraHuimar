package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sandrita
 */
public class ConnectionCuidad {
    
    public static String cadenaConexcion = "jdbc:postgresql://localhost:5432/distribuidorahuimar";
    public static String pgUser = "postgres";
    public static String pgContra = "1234";
    public static Connection con;

    public static Connection getConetion() throws SQLException {
        try {
            con=DriverManager.getConnection(cadenaConexcion, pgUser, pgContra);
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            con = DriverManager.getConnection(cadenaConexcion, pgUser, pgContra);
            System.out.println("¡Conexion exitosa!");
            return con;
        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }

//        try {
//            Class.forName("org.postgresql.Driver");
//           
//            String myBD="jdbc:postgresql://localhost:5432/distribuidorahuimar"; 
//            String usuario="postgres";
//            String pass="1234";
//            
//            Connection cnx=DriverManager.getConnection(myBD, usuario, pass);
//            
//            System.out.println("Conectado");
//            return cnx;
//         
//        }catch(SQLException e){
//            System.out.println("No conecta :c");
//            System.out.println(e.getMessage());  
//        }catch (ClassNotFoundException ex) {
//            System.out.println(ex.getMessage());
//            Logger.getLogger(ConnectionCuidad.class.getName()).log(Level.SEVERE, null, ex);
//        }
        return null;
    }
    
     public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

}
