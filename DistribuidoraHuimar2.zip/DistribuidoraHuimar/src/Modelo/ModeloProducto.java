/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author Sandrita
 */
public class ModeloProducto extends Producto {

    PgConnection cone = new PgConnection();

    public ModeloProducto(int codigopro, String nombrepro, int idcategoria, int stock, String descripcion, double precio, int idproveedor) {
        super(codigopro, nombrepro, idcategoria, stock, descripcion, precio, idproveedor);
    }

    public ModeloProducto() {
    }

    public boolean deleteProductos(String codigoPro) {
        String sql;
        sql = "delete from producto where codigoPro  =" + getCodigopro() + ";";
        return cone.accion(sql);
    }

    public boolean updateProductos(String codigoPro) {
        String sql;
        sql = "update producto set nombrePro ='" + getNombrepro() + "', idcategoria =" + getIdcategoria() + ", stock  =" + getStock() + ", descripcion ='" + getDescripcion() + "',precio =" + getPrecio() + ", idproveedor =" + getIdproveedor() + " where codigopro=" + codigoPro + ";";
        return cone.accion(sql);
    }

    public boolean setProductos() {
        String sql;                                                                                                                 //codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
        sql = "insert into producto (codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor) values (" + getCodigopro() + ", '" + getNombrepro() + "', " + getIdcategoria() + "," + getStock() + ",'" + getDescripcion() + "'," + getPrecio() + "," + getIdproveedor() + ");";
        return cone.accion(sql);
    }

//    public boolean setPersonaFoto() {
//        String sql;
//        sql = "insert into personas(idpersona, nombres, apellidos,fechanacimiento, telefono, sexo, sueldo, cupo, foto)";
//        sql += "values (?,?,?,?,?,?,?,?,?)";
//
//        try {
//            PreparedStatement ps = cone.con.prepareStatement(sql);
//            ps.setString(1, getIdpersona());
//            ps.setString(2, getNombres());
//            ps.setString(3, getApellidos());
//            ps.setDate(4, (java.sql.Date) getFechanacimiento());
//            ps.setString(5, getTelefono());
//            ps.setString(6, getSexo());
//            ps.setDouble(7, getSueldo());
//            ps.setInt(8, getCupo());
//            ps.setBinaryStream(9, getImageFile(), getLenght());
//            ps.executeUpdate();
//
//            return true;
//        } catch (SQLException ex) {
//            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            return false;
//        }
//    }
    public List<Producto> buscar(String buscar) {
        List<Producto> listaProductos = new ArrayList<>();
        String sql;
        if (buscar.equals(null)) {
            sql = "select codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor from  producto";
        } else {
            sql = "select codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor from  producto"
                    + " WHERE UPPER(nombrePro) LIKE UPPER('%" + buscar + "%') OR UPPER(idcategoria) LIKE UPPER('%" + buscar + "%') OR ";
            sql += " UPPER(idproveedor) LIKE UPPER('%" + buscar + "%')";

            try {
                ResultSet rs = cone.consulta(sql);
                while (rs.next()) {
                    Producto pro = new Producto();
                    pro.setCodigopro(rs.getInt(1));
                    pro.setNombrepro(rs.getString(2));
                    pro.setIdcategoria(rs.getInt(3));
                    pro.setStock(rs.getInt(4));
                    pro.setDescripcion(rs.getString(5));
                    pro.setPrecio(rs.getDouble(6));
                    pro.setIdproveedor(rs.getInt(7));

                    listaProductos.add(pro);
                }
                rs.close();

            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(ModeloProducto.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
        return listaProductos;
    }

    public List<Producto> getProductos() {

        String sql = "select * from producto";

        List<Producto> listadoproductos = new ArrayList<>();
        ResultSet rs = cone.consulta(sql);
        try {
            while (rs.next()) {

                Producto pro = new Producto();
                pro.setCodigopro(rs.getInt(1));
                pro.setNombrepro(rs.getString(2));
                pro.setIdcategoria(rs.getInt(3));
                pro.setStock(rs.getInt(4));
                pro.setDescripcion(rs.getString(5));
                pro.setPrecio(rs.getDouble(6));
                pro.setIdproveedor(rs.getInt(7));

                listadoproductos.add(pro);

            }

        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(ModeloProducto.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listadoproductos;

    }
}
