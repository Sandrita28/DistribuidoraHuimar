/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USER
 */
public class PgConnection {
    String cadenaConexcion = "jdbc:postgresql://localhost:5432/distribuidorahuimar";
    String pgUser = "postgres";
    String pgContra = "1234";
    Connection con;

    public PgConnection() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            con = DriverManager.getConnection(cadenaConexcion, pgUser, pgContra);
            System.out.println("¡Conexion exitosa!");
        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    
    public ResultSet consulta(String sql) {

        try {
            Statement st = con.createStatement();
            return st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    }
    
    
     public boolean accion(String nosql) {
        boolean correcto = true;

        try {
            Statement st = con.createStatement();
            st.execute(nosql);
            correcto = true;
        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
            correcto = false;
        }
        return correcto;
    }
    
     
      public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }
}
