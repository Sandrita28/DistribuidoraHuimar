/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.awt.Image;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 *
 * @author USER
 */
public class ModeloCliente extends Cliente {

    PgConnection cone = new PgConnection();

    public ModeloCliente(String cedula, String nombre, String apellido, String gmail, String telefono, int ciudadcliente, String direccion) {
        super(cedula, nombre, apellido, gmail, telefono, ciudadcliente, direccion);
    }

    public ModeloCliente() {
    }

    public boolean deleteClientes(String cedula) {
        String sql;
        sql = "delete from cliente where cedula ='" + getCedula() + "';";
        return cone.accion(sql);
    }

    public boolean updateClientes(String cedula) {
        String sql;
        sql = "update cliente set nombre='" + getNombre() + "', apellido='" + getApellido() + "',gmail='" + getGmail() + "', telefono='" + getTelefono() + "', idciudad =" + getCiudadcliente() + ", direccion='" + getDireccion() + "' where cedula='" + cedula + "';";
        return cone.accion(sql);
    }

    public boolean setClientes() {
        String sql; // cedula;  nombre;  apellido;  gmail;  telefono; ciudadcliente;  direccion;
        sql = "insert into cliente (cedula, nombre, apellido,gmail, telefono, idciudad , direccion) values ('" + getCedula() + "', '" + getNombre() + "', '" + getApellido() + "','" + getGmail() + "','" + getTelefono() + "'," + getCiudadcliente() + ", '" + getDireccion() + "');";
        return cone.accion(sql);
    }

//    public boolean setPersonaFoto() {
//        String sql;
//        sql = "insert into personas(idpersona, nombres, apellidos,fechanacimiento, telefono, sexo, sueldo, cupo, foto)";
//        sql += "values (?,?,?,?,?,?,?,?,?)";
//
//        try {
//            PreparedStatement ps = cone.con.prepareStatement(sql);
//            ps.setString(1, getIdpersona());
//            ps.setString(2, getNombres());
//            ps.setString(3, getApellidos());
//            ps.setDate(4, (java.sql.Date) getFechanacimiento());
//            ps.setString(5, getTelefono());
//            ps.setString(6, getSexo());
//            ps.setDouble(7, getSueldo());
//            ps.setInt(8, getCupo());
//            ps.setBinaryStream(9, getImageFile(), getLenght());
//            ps.executeUpdate();
//
//            return true;
//        } catch (SQLException ex) {
//            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            return false;
//        }
//    }
    public List<Cliente> buscar(String buscar) {
        List<Cliente> listaClientes = new ArrayList<>();
        String sql;
        if (buscar.equals(null)) {
            sql = "select  from  cliente"; 
        } else {
            sql = "select cedula, nombre, apellido,gmail, telefono, idciudad , direccion from cliente"
                    + " WHERE UPPER(nombre) LIKE UPPER('%" + buscar + "%') OR UPPER(apellido) LIKE UPPER('%" + buscar + "%') OR ";
            sql += " UPPER(cedula) LIKE UPPER('%" + buscar + "%')";

            try {
                ResultSet rs = cone.consulta(sql);
                while (rs.next()) {
                    Cliente cli = new Cliente();
                    cli.setCedula(rs.getString(1));
                    cli.setNombre(rs.getString(2));
                    cli.setApellido(rs.getString(3));
                    cli.setGmail(rs.getString(4));
                    cli.setTelefono(rs.getString(5));
                    cli.setCiudadcliente(rs.getInt(6));
                    cli.setDireccion(rs.getString(7));

                    listaClientes.add(cli);
                }
                rs.close();

            } catch (SQLException ex) {
                System.out.println(ex);
                Logger.getLogger(ModeloCliente.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
        return listaClientes;
    }

    public List<Cliente> getClientes() {

        String sql = "select * from cliente";

        List<Cliente> listadoclientes = new ArrayList<>();
        ResultSet rs = cone.consulta(sql);
        try {
            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setCedula(rs.getString(1));//Nombre de la columna de la base de dato.
                cli.setNombre(rs.getString(2));
                cli.setApellido(rs.getString(3));
                cli.setGmail(rs.getString(4));
                cli.setTelefono(rs.getString(5));
                cli.setCiudadcliente(rs.getInt(6));
                cli.setDireccion(rs.getString(7));

                listadoclientes.add(cli);

            }

        } catch (SQLException ex) {
            Logger.getLogger(PgConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(ModeloCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listadoclientes;

    }
}
