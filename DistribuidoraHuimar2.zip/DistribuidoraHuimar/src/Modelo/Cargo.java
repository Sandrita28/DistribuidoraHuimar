/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USER
 */
public class Cargo {
    private  String Idcargo;
    private String nombrecargo;

    public Cargo(String Idcargo, String nombrecargo) {
        this.Idcargo = Idcargo;
        this.nombrecargo = nombrecargo;
    }

    public Cargo() {
    }

    public String getIdcargo() {
        return Idcargo;
    }

    public void setIdcargo(String Idcargo) {
        this.Idcargo = Idcargo;
    }

    public String getNombrecargo() {
        return nombrecargo;
    }

    public void setNombrecargo(String nombrecargo) {
        this.nombrecargo = nombrecargo;
    }
    
    
}
