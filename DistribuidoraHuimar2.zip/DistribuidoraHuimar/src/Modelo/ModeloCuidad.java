/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sandrita
 */
public class ModeloCuidad {

    public List<Ciudad> listaCiudades() {
        ArrayList<Ciudad> ciudad = new ArrayList<>();
        try {
            Connection cone = ConnectionCuidad.getConetion();
            Statement st = cone.createStatement();
            ResultSet rs = st.executeQuery("select idciudad, nombreCiudad, provincia_id from ciudad");
            while (rs.next()) {
                Ciudad pst = new Ciudad();
                pst.setIdciudad(rs.getInt("idciudad"));
                pst.setNombreciudad(rs.getString("nombreCiudad"));
                pst.setProvincia_id(rs.getInt("provincia_id"));
                ciudad.add(pst);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return ciudad;
    }
}
