/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USER
 */
public class Producto {
    private int codigopro;
    private String nombrepro;
    private int idcategoria ;
    private int stock;
    private String descripcion;
    private double precio;
    private int idproveedor ;
    
    public Producto() {
    }

    public Producto(int codigopro, String nombrepro, int idcategoria, int stock, String descripcion, double precio, int idproveedor) {
        this.codigopro = codigopro;
        this.nombrepro = nombrepro;
        this.idcategoria = idcategoria;
        this.stock = stock;
        this.descripcion = descripcion;
        this.precio = precio;
        this.idproveedor = idproveedor;
    }

    public int getCodigopro() {
        return codigopro;
    }

    public void setCodigopro(int codigopro) {
        this.codigopro = codigopro;
    }

    public String getNombrepro() {
        return nombrepro;
    }

    public void setNombrepro(String nombrepro) {
        this.nombrepro = nombrepro;
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(int idproveedor) {
        this.idproveedor = idproveedor;
    }

    
}
