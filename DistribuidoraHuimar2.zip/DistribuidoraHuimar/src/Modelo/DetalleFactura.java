/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;
import java.util.Date;
/**
 *
 * @author USER
 */
public class DetalleFactura {
   
    private String codigoproducto;
    private int cantidad;
    private double valorunitario;
    private double total;

    public DetalleFactura(String codigoproducto, int cantidad, double valorunitario, double total) {
        this.codigoproducto = codigoproducto;
        this.cantidad = cantidad;
        this.valorunitario = valorunitario;
        this.total = total;
    }

    public DetalleFactura() {
    }

    public String getCodigoproducto() {
        return codigoproducto;
    }

    public void setCodigoproducto(String codigoproducto) {
        this.codigoproducto = codigoproducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getValorunitario() {
        return valorunitario;
    }

    public void setValorunitario(double valorunitario) {
        this.valorunitario = valorunitario;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }


 
    
    
}
