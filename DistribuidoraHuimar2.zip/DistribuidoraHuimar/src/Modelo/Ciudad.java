/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USER
 */
public class Ciudad {

    private int idciudad;
    private String nombreciudad;
    private int provincia_id;

    public Ciudad() {

    }

    public Ciudad(int idciudad, String nombreciudad, int provincia_id) {
        this.idciudad = idciudad;
        this.nombreciudad = nombreciudad;
        this.provincia_id = provincia_id;
    }

    public int getIdciudad() {
        return idciudad;
    }

    public void setIdciudad(int idciudad) {
        this.idciudad = idciudad;
    }

    public String getNombreciudad() {
        return nombreciudad;
    }

    public void setNombreciudad(String nombreciudad) {
        this.nombreciudad = nombreciudad;
    }

    public int getProvincia_id() {
        return provincia_id;
    }

    public void setProvincia_id(int provincia_id) {
        this.provincia_id = provincia_id;
    }

    
}
