/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author USER
 */
public class Proveedor {
   private String idproveedor;
   private String nombreproveedor;
   private String apellidoproveedor;
   private String nombreempresa;
   private String cargo;
   private String direccion;
   private String telefono;
   private int ciudad;
   private int cupoventas;

    public Proveedor(String idproveedor, String nombreproveedor, String apellidoproveedor, String nombreempresa, String cargo, String direccion, String telefono, int ciudad, int cupoventas) {
        this.idproveedor = idproveedor;
        this.nombreproveedor = nombreproveedor;
        this.apellidoproveedor = apellidoproveedor;
        this.nombreempresa = nombreempresa;
        this.cargo = cargo;
        this.direccion = direccion;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.cupoventas = cupoventas;
    }

    public Proveedor() {
    }


    public String getIdproveedor() {
        return idproveedor;
    }

    public void setIdproveedor(String idproveedor) {
        this.idproveedor = idproveedor;
    }

    public String getNombreproveedor() {
        return nombreproveedor;
    }

    public void setNombreproveedor(String nombreproveedor) {
        this.nombreproveedor = nombreproveedor;
    }

    public String getApellidoproveedor() {
        return apellidoproveedor;
    }

    public void setApellidoproveedor(String apellidoproveedor) {
        this.apellidoproveedor = apellidoproveedor;
    }

    public String getNombreempresa() {
        return nombreempresa;
    }

    public void setNombreempresa(String nombreempresa) {
        this.nombreempresa = nombreempresa;
    }

    public int getCupoventas() {
        return cupoventas;
    }

    public void setCupoventas(int cupoventas) {
        this.cupoventas = cupoventas;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getCiudad() {
        return ciudad;
    }

    public void setCiudad(int ciudad) {
        this.ciudad = ciudad;
    }
    
    
   
   
           
}
