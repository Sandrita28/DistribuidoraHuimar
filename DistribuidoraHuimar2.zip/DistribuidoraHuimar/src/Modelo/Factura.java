/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;
import java.util.Date;
/**
 *
 * @author USER
 */
public class Factura {
    private int numerofactura;
    private String cedulacliente;
    private Date fecha;
    private double total;
    private String formaenvio;

    public Factura(int numerofactura, String cedulacliente, Date fecha, double total, String formaenvio) {
        this.numerofactura = numerofactura;
        this.cedulacliente = cedulacliente;
        this.fecha = fecha;
        this.total = total;
        this.formaenvio = formaenvio;
    }

    public Factura() {
    }

    public int getNumerofactura() {
        return numerofactura;
    }

    public void setNumerofactura(int numerofactura) {
        this.numerofactura = numerofactura;
    }

    public String getCedulacliente() {
        return cedulacliente;
    }

    public void setCedulacliente(String cedulacliente) {
        this.cedulacliente = cedulacliente;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getFormaenvio() {
        return formaenvio;
    }

    public void setFormaenvio(String formaenvio) {
        this.formaenvio = formaenvio;
    }
    
    
    
    
}
