/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Sandrita
 */
public class ModeloCategoria {
    public List<Categoria> listaCategorias() {
        ArrayList<Categoria> cat = new ArrayList<>();
        try {
            Connection cone = ConnectionCuidad.getConetion();
            Statement st = cone.createStatement();
            ResultSet rs = st.executeQuery("select idcategoria, nombrecategoria from categoria");
            while (rs.next()) {
                Categoria pst = new Categoria();
                pst.setIdcategoria(rs.getInt("idcategoria"));
                pst.setNombrecategoria(rs.getString("nombrecategoria"));
                cat.add(pst);
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        return cat;
    }
}
