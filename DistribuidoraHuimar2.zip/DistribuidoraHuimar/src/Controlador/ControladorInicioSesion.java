/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ModeloInicioSesion;
import Vista.Menu;
import Vista.VistaLogin;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */


public class ControladorInicioSesion {

    VistaLogin login;

    public ControladorInicioSesion(VistaLogin login) {
        this.login = login;
        login.setVisible(true);
        login.setLocationRelativeTo(null);
    }

    public void InciaControl() {
        login.getIniciarSesion().addActionListener(l -> incioSesion());
    }

    public void incioSesion() {
        String user = "Admin";
        String pass = "123";

        if (login.getTxtUsuario().getText().equals(user) && login.getTxtContra().getText().equals(pass)) {
            login.dispose();
            Menu mp = new Menu();
            ControladorMenu controlmp = new ControladorMenu(mp);
            controlmp.InicioControl();            

        } else {
            JOptionPane.showMessageDialog(null, "Usuario/Contraseña incorrecta", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            login.getTxtUsuario().setText("");
            login.getTxtContra().setText("");
        }
    }
}
