/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Ciudad;
import Modelo.Cliente;
import Modelo.ConnectionCuidad;
import Modelo.ModeloCliente;
import Modelo.ModeloCuidad;
import Modelo.PgConnection;
import Vista.VistaClientes;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.Holder;

/**
 *
 * @author USER
 */
public class ControladorCliente {

    private Modelo.ModeloCliente modelo;
    private Vista.VistaClientes vista;
    private JFileChooser jfc;

    public ControladorCliente() {
    }

    public ControladorCliente(ModeloCliente modelo, VistaClientes vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
    }
    public void inciarControl() {
        //CargarDatos();
        vista.getBtnBuscar().addActionListener(l -> buscarClientes());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo(1));
        vista.getBtnModificar().addActionListener(l -> abrirDialogo(2));
        vista.getBtnAceptar().addActionListener(l -> crearEditarClientes());
        vista.getBtnEliminar().addActionListener(l -> eliminarClientes());
//        vista.getBtnExaminar().addActionListener(l -> examinarFoto());
        vista.getBtnCancelar().addActionListener(l -> vista.getDlgCliente().dispose());
//        vista.getBtnMenu().addActionListener(l -> RegresarMenu());
//        vista.getBtnSalir().addActionListener(l -> vista.dispose());
//        vista.getBtnImprimir().addActionListener(l -> imprimeReporte());

        KeyListener kl = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                filtroBuscar(vista.getTxtBuscar().getText());
            }
        };

        vista.getTxtBuscar().addKeyListener(kl);
    }

//    public void imprimeReporte() {
//        //Instanciamos la conexion con el proyecto
//        PgConnection con = new PgConnection();
//
//        try {
//            JasperReport jr = (JasperReport) JRLoader.loadObject(getClass().getResource("/view/Reportes/ReportePersona.jasper"));
//            JasperPrint jp = JasperFillManager.fillReport(jr, null, con.getCon());
//            JasperViewer jv = new JasperViewer(jp, false);
//            jv.setVisible(true);
//        } catch (JRException ex) {
//            Logger.getLogger(ControladorPersona.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//    public void examinarFoto() {
//        jfc = new JFileChooser();
//        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
//        int estado = jfc.showOpenDialog(vista);
//        if (estado == JFileChooser.APPROVE_OPTION) {
//            try {
//                Image imagen = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(
//                        vista.getLblFoto().getWidth(),
//                        vista.getLblFoto().getHeight(),
//                        Image.SCALE_DEFAULT);
//
//                Icon icono = new ImageIcon(imagen);
//                vista.getLblFoto().setIcon(icono);
//                vista.getLblFoto().updateUI();
//            } catch (IOException ex) {
//                Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//    }
    private void limpiarCampos() {
        vista.getTxtCedula().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtApellido().setText("");
        vista.getTxtTelefono().setText("");
        vista.getTxtGmail().setText("");
        vista.getTxtDireccion().setText("");
        //vista.getTxtCuidad().setSelectedItem("");
    }

    public boolean validarCampos() {
        boolean valida = true;

        if (!vista.getTxtCedula().getText().matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(null, "Cedula invalida", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtNombre().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Nombre invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtApellido().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Apellido invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtTelefono().getText().matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(null, "Telefono invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtGmail().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Sueldo invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtDireccion().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Cupo invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }

        return valida;
    }

    private boolean mostrarDatosTabla() {
        int fila = vista.getTablaClientes().getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione el cliente a modificar");
            return false;

        } else {
            String id = vista.getTablaClientes().getValueAt(fila, 0).toString();
            List<Cliente> listap = modelo.getClientes();
            listap.stream().forEach(up -> { // cedula;  nombre;  apellido;  gmail;  telefono; ciudadcliente;  direccion;
                if (id.equalsIgnoreCase(up.getCedula())) {
                    vista.getTxtCedula().setText(up.getCedula());
                    vista.getTxtNombre().setText(up.getNombre());
                    vista.getTxtApellido().setText(up.getApellido());
                    vista.getTxtGmail().setText(up.getGmail());
                    vista.getTxtTelefono().setText(up.getTelefono());
                    vista.getTxtCuidad().setSelectedItem(up.getCiudadcliente());
                    vista.getTxtDireccion().setText(up.getDireccion());
                }
            });

            return true;
        }
    }

    private void abrirDialogo(int op) {
        String titulo;
        if (op == 1) {
            titulo = "Crear Cliente";
            vista.getDlgCliente().setName("c");
            limpiarCampos();
           // llenar_combo_cuidad();
        } else {
            titulo = "Editar Cliente";
            vista.getTxtCedula().setEnabled(false);
            vista.getDlgCliente().setName("e");
            mostrarDatosTabla();
        }

        vista.getDlgCliente().setTitle(titulo);
        vista.getDlgCliente().setSize(700, 600);
        vista.getDlgCliente().setLocationRelativeTo(vista);
        vista.getDlgCliente().setVisible(true);
    }

    private void eliminarClientes() {
        int i = vista.getTablaClientes().getSelectedRow();
        String cedula = vista.getTablaClientes().getValueAt(i, 0).toString();

        int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea eliminar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
        if (respuesta == 0) {
            ModeloCliente cliente = new ModeloCliente();
            cliente.setCedula(cedula);

            if (cliente.deleteClientes(cedula)) {
                JOptionPane.showMessageDialog(vista, "Cliente eliminado satrisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo eliminar :(");
            }
            CargarDatos();
        }
    }

    private void crearEditarClientes() {
        if (vista.getDlgCliente().getName().equals("c")) {
            // cedula;  nombre;  apellido;  gmail;  telefono; ciudadcliente;  direccion;
            String cedula = vista.getTxtCedula().getText();
            String nombre = vista.getTxtNombre().getText();
            String apellido = vista.getTxtApellido().getText();
            String gmail = vista.getTxtGmail().getText();
            String telefono = vista.getTxtTelefono().getText();
            int cuidad = vista.getTxtCuidad().getSelectedIndex();
            String direccion = vista.getTxtDireccion().getText();

            ModeloCliente cliente = new ModeloCliente();
            cliente.setCedula(cedula);
            cliente.setNombre(nombre);
            cliente.setApellido(apellido);
            cliente.setGmail(gmail);
            cliente.setTelefono(telefono);
            cliente.setCiudadcliente(cuidad);
            cliente.setDireccion(direccion);

            //... xd
            if (cliente.setClientes()) {
                JOptionPane.showMessageDialog(vista, "Cliente creado satrisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo crear :(");
            }

        } else {
            //update
            try {
                String cedula = vista.getTxtCedula().getText();
                String nombre = vista.getTxtNombre().getText();
                String apellido = vista.getTxtApellido().getText();
                String gmail = vista.getTxtGmail().getText();
                String telefono = vista.getTxtTelefono().getText();
                int cuidad = vista.getTxtCuidad().getSelectedIndex();
                String direccion = vista.getTxtDireccion().getText();

                ModeloCliente cliente = new ModeloCliente();
                cliente.setCedula(cedula);
                cliente.setNombre(nombre);
                cliente.setApellido(apellido);
                cliente.setGmail(gmail);
                cliente.setTelefono(telefono);
                cliente.setCiudadcliente(cuidad);
                cliente.setDireccion(direccion);

                int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea modificar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
                if (respuesta == 0) {
                    if (cliente.updateClientes(cedula)) {
                        JOptionPane.showMessageDialog(vista, "Cliente modificado satisfactoriamente.");
                    } else {
                        JOptionPane.showMessageDialog(vista, "No se pudo modificar :(");
                    }
                    CargarDatos();
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

            vista.getDlgCliente().dispose();
        }
    }

    private void buscarClientes() {
        String buscar = vista.getTxtBuscar().getText();
        if (buscar.isEmpty()) {
            CargarDatos();
        }
    }

    private void filtroBuscar(String buscar) {
        DefaultTableModel tbmodel;
        tbmodel = (DefaultTableModel) vista.getTablaClientes().getModel();
        tbmodel.setNumRows(0);
        List<Cliente> listap = modelo.buscar(buscar);
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(cli -> {

            tbmodel.addRow(new Object[7]);
            // cedula;  nombre;  apellido;  gmail;  telefono; ciudadcliente;  direccion;
            vista.getTablaClientes().setValueAt(cli.getCedula(), i.value, 0);
            vista.getTablaClientes().setValueAt(cli.getNombre(), i.value, 1);
            vista.getTablaClientes().setValueAt(cli.getApellido(), i.value, 2);
            vista.getTablaClientes().setValueAt(cli.getGmail(), i.value, 3);
            vista.getTablaClientes().setValueAt(cli.getTelefono(), i.value, 4);
            vista.getTablaClientes().setValueAt(cli.getCiudadcliente(), i.value, 5);
            vista.getTablaClientes().setValueAt(cli.getDireccion(), i.value, 6);

            i.value++;
        });
    }

    private void CargarDatos() {
        DefaultTableModel estructuraTabla;
        estructuraTabla = (DefaultTableModel) vista.getTablaClientes().getModel();
        estructuraTabla.setNumRows(0);

        List<Cliente> listap = modelo.getClientes();
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(cli -> {
            // cedula;  nombre;  apellido;  gmail;  telefono; ciudadcliente;  direccion;
            estructuraTabla.addRow(new Object[7]);
            vista.getTablaClientes().setValueAt(cli.getCedula(), i.value, 0);
            vista.getTablaClientes().setValueAt(cli.getNombre(), i.value, 1);
            vista.getTablaClientes().setValueAt(cli.getApellido(), i.value, 2);
            vista.getTablaClientes().setValueAt(cli.getGmail(), i.value, 3);
            vista.getTablaClientes().setValueAt(cli.getTelefono(), i.value, 4);
            vista.getTablaClientes().setValueAt(cli.getCiudadcliente(), i.value, 5);
            vista.getTablaClientes().setValueAt(cli.getDireccion(), i.value, 6);

            i.value++;
        });
    }
    ModeloCuidad ciudad = new ModeloCuidad();
    List<Ciudad> listaCiudad = ciudad.listaCiudades();

    public void llenar_combo_cuidad() {
        vista.getTxtCuidad().removeAllItems();

        for (int i = 0; i < listaCiudad.size(); i++) {
            vista.getTxtCuidad().addItem(listaCiudad.get(i).getNombreciudad());
        }
    }
//    public void RegresarMenu() {
//        this.vista.dispose();
//        Menu m = new Menu();
//        ControladorMenu cm = new ControladorMenu(m);
//        cm.controlMenu();
//    }
}
