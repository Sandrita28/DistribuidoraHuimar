/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Ciudad;
import Modelo.Cliente;
import Modelo.ModeloCliente;
import Modelo.ModeloCuidad;
import Modelo.ModeloProveedor;
import Modelo.PgConnection;
import Modelo.Proveedor;
import Vista.VistaProveedores;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.Holder;

/**
 *
 * @author Sandrita
 */
public class ControladorProveedor {

    private Modelo.ModeloProveedor modelo;
    private Vista.VistaProveedores vista;
    private JFileChooser jfc;

    public ControladorProveedor() {
    }
    
    public ControladorProveedor(ModeloProveedor modelo, VistaProveedores vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
    }

    public void inciarControl() {
        //CargarDatos();
        vista.getBtnBuscar().addActionListener(l -> buscarProveedores());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo(1));
        vista.getBtnModificar().addActionListener(l -> abrirDialogo(2));
        vista.getBtnAceptar().addActionListener(l -> crearEditarClientes());
        vista.getBtnEliminar().addActionListener(l -> eliminarProveedores());
//        vista.getBtnExaminar().addActionListener(l -> examinarFoto());
        vista.getBtnCancelar().addActionListener(l -> vista.getDlgProveedores().dispose());
//        vista.getBtnMenu().addActionListener(l -> RegresarMenu());
//        vista.getBtnSalir().addActionListener(l -> vista.dispose());
//        vista.getBtnImprimir().addActionListener(l -> imprimeReporte());

        KeyListener kl = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                filtroBuscar(vista.getTxtBuscar().getText());
            }
        };

        vista.getTxtBuscar().addKeyListener(kl);
    }

//    public void imprimeReporte() {
//        //Instanciamos la conexion con el proyecto
//        PgConnection con = new PgConnection();
//
//        try {
//            JasperReport jr = (JasperReport) JRLoader.loadObject(getClass().getResource("/view/Reportes/ReportePersona.jasper"));
//            JasperPrint jp = JasperFillManager.fillReport(jr, null, con.getCon());
//            JasperViewer jv = new JasperViewer(jp, false);
//            jv.setVisible(true);
//        } catch (JRException ex) {
//            Logger.getLogger(ControladorPersona.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//    public void examinarFoto() {
//        jfc = new JFileChooser();
//        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
//        int estado = jfc.showOpenDialog(vista);
//        if (estado == JFileChooser.APPROVE_OPTION) {
//            try {
//                Image imagen = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(
//                        vista.getLblFoto().getWidth(),
//                        vista.getLblFoto().getHeight(),
//                        Image.SCALE_DEFAULT);
//
//                Icon icono = new ImageIcon(imagen);
//                vista.getLblFoto().setIcon(icono);
//                vista.getLblFoto().updateUI();
//            } catch (IOException ex) {
//                Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//    }
    private void limpiarCampos() {
        //idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
        vista.getTxtIdproveedor().setText("");
        vista.getTxtNombre().setText("");
        vista.getTxtApellido().setText("");
        vista.getTxtEmpresa().setText("");
        vista.getCmbCargo().setSelectedItem("");
        vista.getTxtTelefono().setText("");
        //vista.getCbmCuidad().setSelectedItem("");
        vista.getTxtDireccion().setText("");
        vista.getSpnCupoventas().setValue(0);
    }

    public boolean validarCampos() {
        boolean valida = true;

        if (!vista.getTxtIdproveedor().getText().matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(null, "Cedula invalida", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtNombre().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Nombre invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtApellido().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Apellido invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtTelefono().getText().matches("[0-9]{10}")) {
            JOptionPane.showMessageDialog(null, "Telefono invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
//        if (!vista.getTxtGmail().getText().matches("[A-Za-z]{1,}")) {
//            JOptionPane.showMessageDialog(null, "Sueldo invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
//            valida = false;
//        }
        if (!vista.getTxtDireccion().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Cupo invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }

        return valida;
    }

    private boolean mostrarDatosTabla() {
        int fila = vista.getTablaProveedores().getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione el proveedor a modificar");
            return false;

        } else {
            String id = vista.getTablaProveedores().getValueAt(fila, 0).toString();
            List<Proveedor> listap = modelo.getProveedores();
            listap.stream().forEach(up -> {
                //idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
                if (id.equalsIgnoreCase(up.getIdproveedor())) {
                    vista.getTxtIdproveedor().setText(up.getIdproveedor());
                    vista.getTxtNombre().setText(up.getNombreproveedor());
                    vista.getTxtApellido().setText(up.getApellidoproveedor());
                    vista.getTxtEmpresa().setText(up.getNombreempresa());
                    vista.getCmbCargo().setSelectedItem(up.getCargo());
                    vista.getTxtDireccion().setText(up.getDireccion());
                    vista.getTxtTelefono().setText(up.getTelefono());
                    vista.getCbmCuidad().setSelectedItem(up.getCiudad());
                    vista.getSpnCupoventas().setValue(up.getCupoventas());
                }
            });

            return true;
        }
    }

    private void abrirDialogo(int op) {
        String titulo;
        if (op == 1) {
            titulo = "Crear Proveedor";
            vista.getDlgProveedores().setName("c");
            limpiarCampos();
            //llenar_combo_cuidad();
        } else {
            titulo = "Editar PRoveedor";
            vista.getTxtIdproveedor().setEnabled(false);
            vista.getDlgProveedores().setName("e");
            mostrarDatosTabla();
        }

        vista.getDlgProveedores().setTitle(titulo);
        vista.getDlgProveedores().setSize(700, 600);
        vista.getDlgProveedores().setLocationRelativeTo(vista);
        vista.getDlgProveedores().setVisible(true);
    }

    private void eliminarProveedores() {
        int i = vista.getTablaProveedores().getSelectedRow();
        String idproveedor = vista.getTablaProveedores().getValueAt(i, 0).toString();

        int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea eliminar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
        if (respuesta == 0) {
            ModeloProveedor proveedor = new ModeloProveedor();
            proveedor.setIdproveedor(idproveedor);

            if (proveedor.deleteProveedores(idproveedor)) {
                JOptionPane.showMessageDialog(vista, "Proveedor eliminado satrisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo eliminar :(");
            }
            CargarDatos();
        }
    }

    private void crearEditarClientes() {
        if (vista.getDlgProveedores().getName().equals("c")) {
            //idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
            String idproveedor = vista.getTxtIdproveedor().getText();
            String nombreproveedor = vista.getTxtNombre().getText();
            String apellidoproveedor = vista.getTxtApellido().getText();
            String nombreempresa = vista.getTxtEmpresa().getText();
            String cargo = vista.getCmbCargo().getSelectedItem().toString();
            String direccion = vista.getTxtDireccion().getText();
            String telefono = vista.getTxtTelefono().getText();
            int cuidad = vista.getCbmCuidad().getSelectedIndex();
            int cupoventas = (int) vista.getSpnCupoventas().getValue();

            ModeloProveedor proveedor = new ModeloProveedor();
            proveedor.setIdproveedor(idproveedor);
            proveedor.setNombreproveedor(nombreproveedor);
            proveedor.setApellidoproveedor(apellidoproveedor);
            proveedor.setNombreempresa(nombreempresa);
            proveedor.setCargo(cargo);
            proveedor.setDireccion(direccion);
            proveedor.setTelefono(telefono);
            proveedor.setCiudad(cuidad);
            proveedor.setCupoventas(cupoventas);

            //... xd
            if (proveedor.setProveedores()) {
                JOptionPane.showMessageDialog(vista, "Proveedor creado satrisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo crear :(");
            }

        } else {
            //update
            try {
                String idproveedor = vista.getTxtIdproveedor().getText();
                String nombreproveedor = vista.getTxtNombre().getText();
                String apellidoproveedor = vista.getTxtApellido().getText();
                String nombreempresa = vista.getTxtEmpresa().getText();
                String cargo = vista.getCmbCargo().getSelectedItem().toString();
                String direccion = vista.getTxtDireccion().getText();
                String telefono = vista.getTxtTelefono().getText();
                int cuidad = vista.getCbmCuidad().getSelectedIndex();
                int cupoventas = (int) vista.getSpnCupoventas().getValue();

                ModeloProveedor proveedor = new ModeloProveedor();
                proveedor.setIdproveedor(idproveedor);
                proveedor.setNombreproveedor(nombreproveedor);
                proveedor.setApellidoproveedor(apellidoproveedor);
                proveedor.setNombreempresa(nombreempresa);
                proveedor.setCargo(cargo);
                proveedor.setDireccion(direccion);
                proveedor.setTelefono(telefono);
                proveedor.setCiudad(cuidad);
                proveedor.setCupoventas(cupoventas);

                int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea modificar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
                if (respuesta == 0) {
                    if (proveedor.updateProveedores(idproveedor)) {
                        JOptionPane.showMessageDialog(vista, "Proveedor modificado satisfactoriamente.");
                    } else {
                        JOptionPane.showMessageDialog(vista, "No se pudo modificar :(");
                    }
                    CargarDatos();
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

            vista.getDlgProveedores().dispose();
        }
    }

    private void buscarProveedores() {
        String buscar = vista.getTxtBuscar().getText();
        if (buscar.isEmpty()) {
            CargarDatos();
        }
    }

    private void filtroBuscar(String buscar) {
        DefaultTableModel tbmodel;
        tbmodel = (DefaultTableModel) vista.getTablaProveedores().getModel();
        tbmodel.setNumRows(0);
        List<Proveedor> listap = modelo.buscar(buscar);
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(prov -> {

            tbmodel.addRow(new Object[9]);
            //idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
            vista.getTablaProveedores().setValueAt(prov.getIdproveedor(), i.value, 0);
            vista.getTablaProveedores().setValueAt(prov.getNombreproveedor(), i.value, 1);
            vista.getTablaProveedores().setValueAt(prov.getApellidoproveedor(), i.value, 2);
            vista.getTablaProveedores().setValueAt(prov.getNombreempresa(), i.value, 3);
            vista.getTablaProveedores().setValueAt(prov.getCargo(), i.value, 4);
            vista.getTablaProveedores().setValueAt(prov.getDireccion(), i.value, 5);
            vista.getTablaProveedores().setValueAt(prov.getTelefono(), i.value, 6);
            vista.getTablaProveedores().setValueAt(prov.getCiudad(), i.value, 7);
            vista.getTablaProveedores().setValueAt(prov.getCupoventas(), i.value, 8);

            i.value++;
        });
    }

    private void CargarDatos() {
        DefaultTableModel estructuraTabla;
        estructuraTabla = (DefaultTableModel) vista.getTablaProveedores().getModel();
        estructuraTabla.setNumRows(0);

        List<Proveedor> listap = modelo.getProveedores();
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(prov -> {
            //idproveedor, nombreproveedor, apellidoproveedor, nombreempresa, cargo, direccion, telefono, ciudad, cupoventas;
            estructuraTabla.addRow(new Object[9]);
            vista.getTablaProveedores().setValueAt(prov.getIdproveedor(), i.value, 0);
            vista.getTablaProveedores().setValueAt(prov.getNombreproveedor(), i.value, 1);
            vista.getTablaProveedores().setValueAt(prov.getApellidoproveedor(), i.value, 2);
            vista.getTablaProveedores().setValueAt(prov.getNombreempresa(), i.value, 3);
            vista.getTablaProveedores().setValueAt(prov.getCargo(), i.value, 4);
            vista.getTablaProveedores().setValueAt(prov.getDireccion(), i.value, 5);
            vista.getTablaProveedores().setValueAt(prov.getTelefono(), i.value, 6);
            vista.getTablaProveedores().setValueAt(prov.getCiudad(), i.value, 7);
            vista.getTablaProveedores().setValueAt(prov.getCupoventas(), i.value, 8);

            i.value++;
        });
    }

    ModeloCuidad ciudad = new ModeloCuidad();
    List<Ciudad> listaCiudad = ciudad.listaCiudades();

    public void llenar_combo_cuidad() {
        vista.getCbmCuidad().removeAllItems();

        for (int i = 0; i < listaCiudad.size(); i++) {
            vista.getCbmCuidad().addItem(listaCiudad.get(i).getNombreciudad());
        }
    }
//    public void RegresarMenu() {
//        this.vista.dispose();
//        Menu m = new Menu();
//        ControladorMenu cm = new ControladorMenu(m);
//        cm.controlMenu();
//    }
}
