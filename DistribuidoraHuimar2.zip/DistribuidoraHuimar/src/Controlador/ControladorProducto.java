/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.Categoria;
import Modelo.Ciudad;
import Modelo.ModeloCategoria;
import Modelo.ModeloCuidad;
import Modelo.ModeloProducto;
import Modelo.ModeloProveedor;
import Modelo.PgConnection;
import Modelo.Producto;
import Modelo.Proveedor;
import Vista.Menu;
import Vista.VistaProductos;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.xml.ws.Holder;

/**
 *
 * @author Sandrita
 */
public class ControladorProducto {

    private ModeloProducto modelo;
    private VistaProductos vista;
    private JFileChooser jfc;

    public ControladorProducto() {
    }

    public ControladorProducto(ModeloProducto modelo, VistaProductos vista) {
        this.modelo = modelo;
        this.vista = vista;
        vista.setVisible(true);
    }

    public void inciarControl() {
        CargarDatos();
        vista.getBtnBuscar().addActionListener(l -> buscarProductos());
        vista.getBtnCrear().addActionListener(l -> abrirDialogo(1));
        vista.getBtnModificar().addActionListener(l -> abrirDialogo(2));
        vista.getBtnAceptar().addActionListener(l -> crearEditarProductos());
        vista.getBtnEliminar().addActionListener(l -> eliminarProductos());
        //vista.getBtnExaminar().addActionListener(l -> examinarFoto());
        vista.getBtnCancelar().addActionListener(l -> vista.getDlgProducto().dispose());
        //vista.getBtnImprimir().addActionListener(l -> imprimeReporte());

        KeyListener kl = new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                filtroBuscar(vista.getTxtBuscar().getText());
            }
        };

        vista.getTxtBuscar().addKeyListener(kl);
    }

//    public void imprimeReporte() {
//        //Instanciamos la conexion con el proyecto
//        PgConnection con = new PgConnection();
//
//        try {
//            JasperReport jr = (JasperReport) JRLoader.loadObject(getClass().getResource("/view/Reportes/ReportePersona.jasper"));
//            JasperPrint jp = JasperFillManager.fillReport(jr, null, con.getCon());
//            JasperViewer jv = new JasperViewer(jp, false);
//            jv.setVisible(true);
//        } catch (JRException ex) {
//            Logger.getLogger(ControladorPersona.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

//    public void examinarFoto() {
//        jfc = new JFileChooser();
//        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
//        int estado = jfc.showOpenDialog(vista);
//        if (estado == JFileChooser.APPROVE_OPTION) {
//            try {
//                Image imagen = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(
//                        vista.getLblFoto().getWidth(),
//                        vista.getLblFoto().getHeight(),
//                        Image.SCALE_DEFAULT);
//
//                Icon icono = new ImageIcon(imagen);
//                vista.getLblFoto().setIcon(icono);
//                vista.getLblFoto().updateUI();
//            } catch (IOException ex) {
//                Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//    }

    private void limpiarCampos() {
        //codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
        vista.getTxtCodpro().setText("");
        vista.getTxtNombrepro().setText("");
        vista.getCmbCategoria().setSelectedItem("");
        vista.getCmbProveedor().setSelectedItem("");
        vista.getTxtDescripcion().setText("");
        vista.getTxtPrecio().setText("");
        vista.getSpnStock().setValue(0);
    }

    public boolean validarCampos() {
        boolean valida = true;

        if (!vista.getTxtCodpro().getText().matches("[0-9]{1, }")) {
            JOptionPane.showMessageDialog(null, "Codigo invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtNombrepro().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Nombre invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        if (!vista.getTxtDescripcion().getText().matches("[A-Za-z]{1,}")) {
            JOptionPane.showMessageDialog(null, "Descripcion invalido", "ERROR_MESSAGE", JOptionPane.ERROR_MESSAGE);
            valida = false;
        }
        
        return valida;
    }

    private boolean mostrarDatosTabla() {
        int fila = vista.getTablaProductos().getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(null, "Seleccione el producto a modificar");
            return false;

        } else {
            String id = vista.getTablaProductos().getValueAt(fila, 0).toString();
            List<Producto> listap = modelo.getProductos();
            listap.stream().forEach(up -> {
                //codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
                if (id.equalsIgnoreCase(up.getCodigopro() + "")) {
                    vista.getTxtCodpro().setText(up.getCodigopro() + "");
                    vista.getTxtNombrepro().setText(up.getNombrepro());
                    vista.getCmbCategoria().setSelectedIndex(up.getIdcategoria());
                    vista.getSpnStock().setValue(up.getStock());
                    vista.getTxtDescripcion().setText(up.getDescripcion());
                    vista.getTxtPrecio().setText(up.getPrecio() + "");
                    vista.getCmbProveedor().setSelectedIndex(up.getIdproveedor());
                }
            });

            return true;
        }
    }

    private void abrirDialogo(int op) {
        String titulo;
        if (op == 1) {
            titulo = "Crear Producto";
            vista.getDlgProducto().setName("c");
            limpiarCampos();
            //llenar_combo_categoria();
        } else {
            titulo = "Editar Producto";
            vista.getTxtCodpro().setEnabled(false);
            vista.getDlgProducto().setName("e");
            mostrarDatosTabla();
        }

        vista.getDlgProducto().setTitle(titulo);
        vista.getDlgProducto().setSize(700, 600);
        vista.getDlgProducto().setLocationRelativeTo(vista);
        vista.getDlgProducto().setVisible(true);
    }

    private void eliminarProductos() {
        int i = vista.getTablaProductos().getSelectedRow();
        int codigoPro = Integer.parseInt(vista.getTablaProductos().getValueAt(i, 0).toString());

        int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea eliminar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
        if (respuesta == 0) {
            ModeloProducto pro = new ModeloProducto();
            pro.setCodigopro(codigoPro);

            if (pro.deleteProductos(codigoPro+"")) {
                JOptionPane.showMessageDialog(vista, "Producto eliminado satisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo eliminar :(");
            }
            CargarDatos();
        }
    }

    private void crearEditarProductos() {
        if (vista.getDlgProducto().getName().equals("c")) {
            ////codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
            int codigoPro = Integer.parseInt(vista.getTxtCodpro().getText());
            String nombreproveedor = vista.getTxtNombrepro().getText();
            int idcategoria = vista.getCmbCategoria().getSelectedIndex();
            int stock = (int) vista.getSpnStock().getValue();
            String descripcion = vista.getTxtDescripcion().getText();
            double precio = Double.parseDouble(vista.getTxtPrecio().getText());
            int idproveedor = vista.getCmbProveedor().getSelectedIndex();

            ModeloProducto pro = new ModeloProducto();
            pro.setCodigopro(codigoPro);
            pro.setNombrepro(nombreproveedor);
            pro.setIdcategoria(idcategoria);
            pro.setStock(stock);
            pro.setDescripcion(descripcion);
            pro.setPrecio(precio);
            pro.setIdproveedor(idproveedor);
            //... xd
            if (pro.setProductos()) {
                JOptionPane.showMessageDialog(vista, "Producto creado satrisfactoriamente.");
            } else {
                JOptionPane.showMessageDialog(vista, "No se pudo crear :(");
            }

        } else {
            //update
            try {
                ////codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
                int codigoPro = Integer.parseInt(vista.getTxtCodpro().getText());
                String nombreproveedor = vista.getTxtNombrepro().getText();
                int idcategoria = vista.getCmbCategoria().getSelectedIndex();
                int stock = (int) vista.getSpnStock().getValue();
                String descripcion = vista.getTxtDescripcion().getText();
                double precio = Double.parseDouble(vista.getTxtPrecio().getText());
                int idproveedor = vista.getCmbProveedor().getSelectedIndex();

                ModeloProducto pro = new ModeloProducto();
                pro.setCodigopro(codigoPro);
                pro.setNombrepro(nombreproveedor);
                pro.setIdcategoria(idcategoria);
                pro.setStock(stock);
                pro.setDescripcion(descripcion);
                pro.setPrecio(precio);
                pro.setIdproveedor(idproveedor);

                int respuesta = JOptionPane.showConfirmDialog(null, "Esta seguro que desea modificar el registro?", "CONFIRMATION_MESSAGE", JOptionPane.YES_NO_OPTION);
                if (respuesta == 0) {
                    if (pro.updateProductos(codigoPro+"")) {
                        JOptionPane.showMessageDialog(vista, "Producto modificado satisfactoriamente.");
                    } else {
                        JOptionPane.showMessageDialog(vista, "No se pudo modificar :(");
                    }
                    CargarDatos();
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }

            vista.getDlgProducto().dispose();
        }
    }

    private void buscarProductos() {
        String buscar = vista.getTxtBuscar().getText();
        if (buscar.isEmpty()) {
            CargarDatos();
        }
    }

    private void filtroBuscar(String buscar) {
        DefaultTableModel tbmodel;
        tbmodel = (DefaultTableModel) vista.getTablaProductos().getModel();
        tbmodel.setNumRows(0);
        List<Producto> listap = modelo.buscar(buscar);
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(prov -> {

            tbmodel.addRow(new Object[7]);
            //codigoPro , nombrePro , idcategoria , stock , descripcion , precio , idproveedor
            vista.getTablaProductos().setValueAt(prov.getCodigopro(), i.value, 0);
            vista.getTablaProductos().setValueAt(prov.getNombrepro(), i.value, 1);
            vista.getTablaProductos().setValueAt(prov.getIdcategoria(), i.value, 2);
            vista.getTablaProductos().setValueAt(prov.getStock(), i.value, 3);
            vista.getTablaProductos().setValueAt(prov.getDescripcion(), i.value, 4);
            vista.getTablaProductos().setValueAt(prov.getPrecio(), i.value, 5);
            vista.getTablaProductos().setValueAt(prov.getIdproveedor(), i.value, 6);

            i.value++;
        });
    }

    private void CargarDatos() {
        DefaultTableModel estructuraTabla;
        estructuraTabla = (DefaultTableModel) vista.getTablaProductos().getModel();
        estructuraTabla.setNumRows(0);

        List<Producto> listap = modelo.getProductos();
        Holder<Integer> i = new Holder<>(0);
        listap.stream().forEach(pro -> {
            //codigopro, nombrepro, idcategoria, stock, descripcion, precio, idproveedor
            estructuraTabla.addRow(new Object[7]);
            vista.getTablaProductos().setValueAt(pro.getCodigopro(), i.value, 0);
            vista.getTablaProductos().setValueAt(pro.getNombrepro(), i.value, 1);
            vista.getTablaProductos().setValueAt(pro.getIdcategoria(), i.value, 2);
            vista.getTablaProductos().setValueAt(pro.getStock(), i.value, 3);
            vista.getTablaProductos().setValueAt(pro.getDescripcion(), i.value, 4);
            vista.getTablaProductos().setValueAt(pro.getPrecio(), i.value, 5);
            vista.getTablaProductos().setValueAt(pro.getIdproveedor(), i.value, 6);

            i.value++;
        });
    }

    ModeloCategoria cat = new ModeloCategoria();
    List<Categoria> listaCat = cat.listaCategorias();

    public void llenar_combo_categoria() {
        vista.getCmbCategoria().removeAllItems();

        for (int i = 0; i < listaCat.size(); i++) {
            vista.getCmbCategoria().addItem(listaCat.get(i).getNombrecategoria());
        }
    }

//    public void RegresarMenu() {
//        this.vista.dispose();
//        Menu m = new Menu();
//        ControladorMenu cm = new ControladorMenu(m);
//        cm.controlMenu();
//    }
}
