/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Modelo.ModeloCliente;
import Modelo.ModeloProducto;
import Modelo.ModeloProveedor;
import Vista.Menu;
import Vista.VistaClientes;
import Vista.VistaProductos;
import Vista.VistaProveedores;
//import Vista.IngresoClientes;

/**
 *
 * @author USER
 */
public class ControladorMenu {
    
    Menu menu;
    
    public ControladorMenu(Menu menu) {
        this.menu = menu;
        menu.setVisible(true);
        menu.setLocationRelativeTo(null);
    }
    
    public void InicioControl() {
        menu.getBtnClientes().addActionListener(l -> crudClientes());
        menu.getMnuClientes().addActionListener(l -> crudClientes());
        
        menu.getBtnProveedores().addActionListener(l -> crudProveedores());
        menu.getMnuProveedores().addActionListener(l -> crudProveedores());
        
        menu.getBtnProductos().addActionListener(l -> crudProductos());
        menu.getMnuProductos().addActionListener(l -> crudProductos());
    }
    
    private void crudClientes() {
        
        ModeloCliente m = new ModeloCliente();
        VistaClientes v = new VistaClientes();
        menu.getDskMenu().add(v);
        
        ControladorCliente c = new ControladorCliente(m, v);
        c.inciarControl();
    }
    
    private void crudProveedores() {
        ModeloProveedor modelo = new ModeloProveedor();
        VistaProveedores vista = new VistaProveedores();
        menu.getDskMenu().add(menu);
        
        ControladorProveedor control = new ControladorProveedor(modelo, vista);
        control.inciarControl();
    }
    
    private void crudProductos() {
        ModeloProducto modelo = new ModeloProducto();
        VistaProductos vista = new VistaProductos();
        menu.getDskMenu().add(menu);
        
        ControladorProducto control = new ControladorProducto(modelo, vista);
        control.inciarControl();
    }
}
