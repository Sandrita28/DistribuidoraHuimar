/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package distribuidorahuimar;

import Controlador.ControladorInicioSesion;
import Vista.Menu;
import Vista.VistaLogin;

/**
 *
 * @author USER
 */
public class DistribuidoraHuimar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        VistaLogin login = new VistaLogin();
        ControladorInicioSesion sesion = new ControladorInicioSesion(login);
        sesion.InciaControl();
    }

}
